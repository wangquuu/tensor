package BBTTD;


import LFTcommom.InitTensor;
import LFTcommom.TensorTuple;

import java.io.IOException;

//更新顺序U,S,T,a,b,c


public class BBTTD extends InitTensor{

    public double sumTime = 0; //训练累计时间

    public int tr = 0;  //统计本轮迭代与前一轮小于误差的次数

    public int threshold = 0;  //连续下降轮数小于误差范围切达到阈值终止训练

    public boolean flagRMSE = true, flagMAE = true;

    public String str = null;

    public double lambda = 0;  //因子矩阵正则化参数
    public double lambda_b = 0;  //线性偏差正则化参数



    BBTTD(String trainFile, String validFile, String testFile, String separator )
    {
        super(trainFile, validFile, testFile, separator);
    }

    public void train() throws IOException
    {
        long startTime = System.currentTimeMillis();   //记录开始训练时间

//		FileWriter  fw = new FileWriter(new File(trainFile.replace(".txt", "_")+rank+"_"+lambda+"_"+
//		                lambda_b+"_"+new Date().getTime() / 1000+"_BNLFT.txt"));
//
//		fw.write("round :: everyRoundRMSE :: everyRoundMAE :: costTime(ms) \n");
//		fw.flush();

        initFactorMatrix();
        initAssistMatrix();
//		initSliceSet();

//		System.out.println("maxAID maxBID maxCID "+maxAID+" "+maxBID+" "+maxCID);
//		System.out.println("minAID minBID minCID "+minAID+" "+minBID+" "+minCID);
//		System.out.println("trainCount validCount testCount "+trainCount+" "+validCount+" "+testCount);
//		System.out.println("初始范围:"+initscale);
//		System.out.println("lambda  lambda_b: "+lambda+" "+lambda_b);


        for(int round = 1; round <= trainRound; round++)
        {
            long startRoundTime = System.currentTimeMillis();    //记录每轮的训练时间

            initAssistMatrix();

            for(TensorTuple trainTuple: trainData)
            {
                trainTuple.valueHat = this.getPrediction(trainTuple.aID,trainTuple.bID, trainTuple.cID);

                for(int r1 = 1; r1 <= rank; r1++) {
                    for (int r2 = 1; r2 <= rank1; r2++) {
                        Sup[trainTuple.aID][r1][r2] += trainTuple.value *
                                D[trainTuple.bID][r1][r2] * T[trainTuple.cID][r1];
                        Sdown[trainTuple.aID][r1][r2] += trainTuple.valueHat *
                                D[trainTuple.bID][r1][r2] * T[trainTuple.cID][r1] + lambda * S[trainTuple.aID][r1][r2];
                    }
                }
            }

            for(int i = 1; i <= this.maxAID; i++) {
                for(int r1=1; r1 <= rank; r1++) {
                    for (int r2 = 1; r2 <= rank1; r2++) {
                        Sup[i][r1][r2] = S[i][r1][r2] * Sup[i][r1][r2];
                        if(Sdown[i][r1][r2] != 0)
                        {
                            S[i][r1][r2] = Sup[i][r1][r2] / Sdown[i][r1][r2];
                        }
                    }
                }
            }


            for(TensorTuple trainTuple: trainData)
            {
                trainTuple.valueHat = this.getPrediction(trainTuple.aID,trainTuple.bID, trainTuple.cID);

                for(int r1 = 1; r1 <= rank; r1++) {
                    for (int r2 = 1; r2 <= rank1; r2++) {
                        Dup[trainTuple.bID][r1][r2] += trainTuple.value * S[trainTuple.aID][r1][r2] * T[trainTuple.cID][r1];
                        Ddown[trainTuple.bID][r1][r2] += trainTuple.valueHat *
                                S[trainTuple.aID][r1][r2] * T[trainTuple.cID][r1] + lambda * D[trainTuple.bID][r1][r2];
                    }
                }
            }

            for(int i = 1; i <= this.maxBID; i++) {
                for(int r1=1; r1 <= rank; r1++) {
                    for (int r2 = 1; r2 <= rank1; r2++) {
                        Dup[i][r1][r2] = D[i][r1][r2] * Dup[i][r1][r2];
                        if(Ddown[i][r1][r2] != 0)
                        {
                            D[i][r1][r2] = Dup[i][r1][r2] / Ddown[i][r1][r2];
                        }
                    }
                }
            }


            for(TensorTuple trainTuple: trainData)
            {
                trainTuple.valueHat = this.getPrediction(trainTuple.aID,trainTuple.bID, trainTuple.cID);

                for(int r1 = 1; r1 <= rank; r1++) {
                    double temp = 0;
                    for (int r2 = 1; r2 <= rank1; r2++) {
                            temp += S[trainTuple.aID][r1][r2] * D[trainTuple.bID][r1][r2];
                    }
                    Tup[trainTuple.cID][r1] += trainTuple.value * temp;
                    Tdown[trainTuple.cID][r1] += trainTuple.valueHat * temp + lambda * T[trainTuple.cID][r1];
                }
            }

            for(int i = 1; i <= this.maxCID; i++) {
                for(int r1=1; r1 <= rank; r1++) {
                    Tup[i][r1] = T[i][r1] * Tup[i][r1];
                    if(Tdown[i][r1] != 0)
                    {
                        T[i][r1] = Tup[i][r1] / Tdown[i][r1];
                    }
                }
            }



            for(TensorTuple trainTuple: trainData)
            {
                trainTuple.valueHat = this.getPrediction(trainTuple.aID,trainTuple.bID, trainTuple.cID);

                for(int r = 1; r <= rank1; r++)
                {
                    aup[trainTuple.aID][r] += trainTuple.value;
                    adown[trainTuple.aID][r] += trainTuple.valueHat + lambda_b * a[trainTuple.aID][r];
                }
            }

            for(int i = 1; i <= this.maxAID; i++) {
                for(int r=1; r <= rank1; r++) {
                    aup[i][r] = a[i][r] * aup[i][r];
                    if(adown[i][r] != 0) {
                        a[i][r] = aup[i][r] / adown[i][r];
                    }
                }
            }


            for(TensorTuple trainTuple: trainData)
            {
                trainTuple.valueHat = this.getPrediction(trainTuple.aID,trainTuple.bID, trainTuple.cID);

                for(int r = 1; r <= rank1; r++)
                {
                    bup[trainTuple.bID][r] += trainTuple.value;
                    bdown[trainTuple.bID][r] += trainTuple.valueHat + lambda_b * b[trainTuple.bID][r];
                }
            }

            for(int i = 1; i <= this.maxBID; i++) {
                for(int r=1; r <= rank1; r++) {
                    bup[i][r] = b[i][r] * bup[i][r];
                    if(bdown[i][r] != 0) {
                        b[i][r] = bup[i][r] / bdown[i][r];
                    }
                }
            }


            for(TensorTuple trainTuple: trainData)
            {
                trainTuple.valueHat = this.getPrediction(trainTuple.aID,trainTuple.bID, trainTuple.cID);
                cup[trainTuple.cID] += trainTuple.value;
                cdown[trainTuple.cID] += trainTuple.valueHat +lambda_b * c[trainTuple.cID];
            }

            for(int k = 1; k <= this.maxCID; k++)
            {
                cup[k] = c[k] * cup[k];
                if(cdown[k] != 0)
                {
                    c[k] = cup[k] / cdown[k];
                }
            }



            // 每一轮参数更新后，开始对验证集测试
            double square = 0, absCount = 0;
            for (TensorTuple validTuple : validData) {
                // 获得元素的预测值
                validTuple.valueHat = this.getPrediction(validTuple.aID, validTuple.bID, validTuple.cID);
                square += Math.pow(validTuple.value - validTuple.valueHat, 2);
                absCount += Math.abs(validTuple.value - validTuple.valueHat);

            }

            everyRoundRMSE[round] = Math.sqrt(square / validCount);
            everyRoundMAE[round] = absCount / validCount;

            long endRoundTime = System.currentTimeMillis();
            sumTime += (endRoundTime-startRoundTime);

            // 每一轮参数更新后，记录测试集结果
            double square2 = 0, absCount2 = 0;
            for (TensorTuple testTuple : testData) {
                // 获得元素的预测值
                testTuple.valueHat = this.getPrediction(testTuple.aID, testTuple.bID, testTuple.cID);
                square2 += Math.pow(testTuple.value - testTuple.valueHat, 2);
                absCount2 += Math.abs(testTuple.value - testTuple.valueHat);
            }

            everyRoundRMSE2[round] = Math.sqrt(square2 / testCount);
            everyRoundMAE2[round] = absCount2 / testCount;

            System.out.println(round + "::" + everyRoundRMSE[round] + "::" + everyRoundMAE[round]
                    +"::"+ (endRoundTime-startRoundTime)+"::"+ everyRoundRMSE2[round] + "::" + everyRoundMAE2[round]);

//            System.out.println((everyRoundRMSE2[round] + " " + everyRoundMAE2[round]));
//			fw.write(round + "::" + everyRoundRMSE[round] + "::" + everyRoundMAE[round]
//					+"::"+ (endRoundTime-startRoundTime)+"::"+ everyRoundRMSE2[round] + "::" + everyRoundMAE2[round]+"\n");
//			fw.flush();

            if (everyRoundRMSE[round-1] - everyRoundRMSE[round] > errorgap)
            {
                if(minRMSE > everyRoundRMSE[round])
                {
                    minRMSE = everyRoundRMSE[round];
                    minRMSERound = round;
                }

                flagRMSE = false;
                tr = 0;
            }

            if (everyRoundMAE[round-1] - everyRoundMAE[round] > errorgap)
            {
                if(minMAE > everyRoundMAE[round])
                {
                    minMAE = everyRoundMAE[round];
                    minMAERound = round;
                }

                flagMAE = false;
                tr = 0;
            }

            if(flagRMSE && flagMAE)
            {
                tr++;
                if(tr == threshold)
                    break;
            }

            flagRMSE = true;
            flagMAE = true;

        }

        long endTime = System.currentTimeMillis();

//		fw.write("总训练时间："+(endTime-startTime)/1000+"s\n");
//		fw.flush();
//		fw.write("validation minRMSE:"+minRMSE+"  minRSMERound"+minRMSERound+"\n");
//		fw.write("validation minMAE:"+minMAE+"  minMAERound"+minMAERound+"\n");
//		fw.write("testing minRMSE:"+everyRoundRMSE2[minRMSERound]+"  minRSMERound"+minRMSERound+"\n");
//		fw.write("testing minMAE:"+everyRoundMAE2[minMAERound]+"  minMAERound"+minMAERound+"\n");
//		fw.flush();
//		fw.write("rank="+rank+"\n");
//		fw.flush();
//		fw.write("trainCount: "+trainCount+"validCount: "+validCount+"   testCount: "+testCount+"\n");
//		fw.flush();
//        SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");//设置日期格式
//        fw.write("训练时间："+df.format(new Date())+"\n");// new Date()为获取当前系统时间
//        fw.flush();
//		fw.write("初始范围"+initscale+"\n");
//		fw.flush();
//		fw.write("maxAID maxBID maxCID "+maxAID+" "+maxBID+" "+maxCID+"\n");
//		fw.write("minAID minBID minCID "+minAID+" "+minBID+" "+minCID+"\n");
//		fw.close();

//		System.out.println("***********************************************");
////		System.out.println("rank: "+this.rank+"\n");
////		System.out.println("validation minRMSE:"+minRMSE+"  minRSMERound"+minRMSERound);
////		System.out.println("validation minMAE:"+minMAE+"  minMAERound"+minMAERound);
        System.out.println("总训练时间："+(endTime-startTime)/1000.00+"s");
        System.out.println("testing minRMSE:"+everyRoundRMSE2[minRMSERound]+"  minRSMERound"+minRMSERound);
        System.out.println("testing minMAE:"+everyRoundMAE2[minMAERound]+"  minMAERound"+minMAERound);

//		System.out.println(everyRoundRMSE2[minRMSERound]+" "+minRMSERound+" "+everyRoundMAE2[minMAERound]+" "+minMAERound);

    }

    public static void main(String[] args) {
        // TODO Auto-generated method stub

        //训练：验证：测试=5%：5%：90%
        BBTTD bbttd = new BBTTD("E:\\file\\DATAsets\\QS\\tp\\0.6\\tr.txt",
                "E:\\file\\DATAsets\\QS\\tp\\0.6\\va.txt",
                "E:\\file\\DATAsets\\QS\\tp\\0.6\\te.txt","::");


        bbttd.initscale = 0.2;
        bbttd.initscale2 = 0.2;
        bbttd.threshold = 2;
        bbttd.rank = 5;
        bbttd.rank1 = 5;
        bbttd.trainRound = 1000;
        bbttd.errorgap = 1E-5;
        bbttd.lambda = 0.4;     //根据数据集设置
        bbttd.lambda_b = 0.4;   //根据数据集设置

        try {
            bbttd.initData(bbttd.trainFile, bbttd.trainData, 1);
            bbttd.initData(bbttd.validFile, bbttd.validData, 2);
            bbttd.initData(bbttd.testFile, bbttd.testData, 3);
            bbttd.train();
        } catch (IOException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }

//        try {
//            bnlft.initData(bnlft.trainFile, bnlft.trainData, 1);
//            bnlft.initData(bnlft.validFile, bnlft.validData, 2);
//            bnlft.initData(bnlft.testFile, bnlft.testData, 3);
//        } catch (IOException e) {
//            // TODO Auto-generated catch block
//            e.printStackTrace();
//        }
//
//		for (int j = 1; j <= 1; j++) {
//            for (int i = 1; i <= 5; i++) {
//                bnlft.initscale = 0.2;
//                bnlft.initscale2 = 0.001;
//                bnlft.threshold = 2;
//                bnlft.rank = 5;
//                bnlft.rank1 = 5+i;
//                bnlft.trainRound = 1000;
//                bnlft.errorgap = 1E-5;
//                bnlft.lambda = 0.2;     //根据数据集设置
//                bnlft.lambda_b = 0.4;   //根据数据集设置
//                System.out.println("**********************************************************");
//                System.out.println("lambda1:" + bnlft.lambda + "   lambda2:" + bnlft.lambda_b);
//
//                try {
//                    bnlft.train();
//                } catch (IOException e) {
//                    // TODO Auto-generated catch block
//                    e.printStackTrace();
//                }
//            }
//		}



    }
}

